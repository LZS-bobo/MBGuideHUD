//
//  LZSGuideHUD.h
//  SDGuideView
//
//  Created by 罗壮燊 on 16/8/22.
//  Copyright © 2016年 lzs. All rights reserved.
//

#import "MBGuideHUD.h"

@interface LZSGuideHUD : MBGuideHUD

@end
